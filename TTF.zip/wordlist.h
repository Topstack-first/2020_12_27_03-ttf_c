#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <malloc.h>
#include <string.h>

typedef struct {
	char* data;
	int occurrences;
}Word;

typedef struct wordnode {
	Word wordData;
	struct wordnode* next;
}WordNode;

typedef struct {
	WordNode* head;
}WordList;

WordList* createList();
void addSorted(WordList* list, char* data);
void removeList(WordList* from, char* toRemove);
void printList(WordList* list);
void destroyList(WordList* list);

