
#include "wordlist.h"

WordList* createList()
{
	WordList* newList = 0;
	newList = (WordList*)malloc(sizeof(WordList));
	if (newList == 0)
	{
		return 0;
	}
	newList->head = 0;
	return newList;
}
void addSorted(WordList* list, char* data) {
	WordNode* curNode = list->head;
	WordNode* preNode = 0;
	while (curNode != 0)
	{
		if (strcmp(curNode->wordData.data, data) == 0)
		{
			curNode->wordData.occurrences += 1;
			return;
		}
		else if (strcmp(curNode->wordData.data, data) < 0)
		{
			preNode = curNode;
		}
		curNode = curNode->next;
	}
	WordNode * newNode = (WordNode*)malloc(sizeof(WordNode));
	if (newNode == 0)
	{
		return;
	}
	newNode->wordData.occurrences = 1;
	newNode->next = 0;
	newNode->wordData.data = (char*)malloc(sizeof(char) * strlen(data));
	if (newNode->wordData.data == 0)
	{
		return;
	}
	strcpy(newNode->wordData.data, data);

	if (preNode == 0)
	{
		//into head
		newNode->next = list->head;
		list->head = newNode;
	}
	else
	{
		newNode->next = preNode->next;
		preNode->next = newNode;

	}
}
void removeList(WordList* from, char* toRemove)
{
	char* readWord = "";
	FILE* fp = fopen(toRemove, "r");
	if (fp == 0)
	{
		return;
	}
	while(readWord != 0)
	{
		char word[100];
		int ch, i = 0;

		while (EOF != (ch = fgetc(fp)) && !isalpha(ch))
			;//skip
		if (ch == EOF)
			break;
		do {
			word[i++] = tolower(ch);
		} while (EOF != (ch = fgetc(fp)) && isalpha(ch));

		word[i] = '\0';
		readWord = _strdup(word);

		WordNode* curNode = from->head;
		WordNode* preNode = 0;
		while (curNode != 0)
		{
			WordNode* tempNode = curNode;
			WordNode* tempPreNode = preNode;

			curNode = curNode->next;
			if (strcmp(tempNode->wordData.data, readWord) == 0)
			{
				if (tempPreNode == 0)
				{
					from->head = tempNode->next;
				}
				else
				{
					tempPreNode->next = tempNode->next;
				}
				free(tempNode);
				break;
			}
			else
			{
				preNode = tempNode;
			}
			
		}
	}
	fclose(fp);
}
void printList(WordList* list)
{
	WordNode* curNode = list->head;
	while (curNode != 0)
	{
		printf("%s,%d\n", curNode->wordData.data, curNode->wordData.occurrences);
		curNode = curNode->next;
	}
}
void destroyList(WordList* list)
{
	WordNode* curNode = list->head;
	while (curNode != 0)
	{
		WordNode* tempNode = curNode;
		curNode = curNode->next;

		free(tempNode);
	}
	free(list);
}

