// TTF.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "wordlist.h"
#define MIN_OCCURENCES 2

int main(int argc,char* argv[])
{
	if (argc < 3)
	{
		printf("this program has two parameters");
		return 0;
	}
	char* documentFile = argv[1];
	char* stopwordsFile = argv[2];

    WordList* wordlist = createList();

	char* readWord = "";
	FILE* fp = fopen(documentFile, "r");

	int threshold = MIN_OCCURENCES;

	if (fp == 0)
	{
		return;
	}
	while (readWord != 0)
	{
		char word[100];
		int ch, i = 0;

		while (EOF != (ch = fgetc(fp)) && !isalpha(ch))
			;//skip
		if (ch == EOF)
			break;
		do {
			word[i++] = tolower(ch);
		} while (EOF != (ch = fgetc(fp)) && isalpha(ch));

		word[i] = '\0';
		readWord = _strdup(word);

		addSorted(wordlist, readWord);
	}
	fclose(fp);

	printList(wordlist);
	
	WordNode* curNode = wordlist->head;
	WordNode* preNode = 0;
	while (curNode != 0)
	{
		WordNode* tempNode = curNode;
		WordNode* tempPreNode = preNode;
		
		curNode = curNode->next;
		if (tempNode->wordData.occurrences < threshold)
		{
			if (tempPreNode == 0)
			{
				wordlist->head = tempNode->next;
			}
			else {
				tempPreNode->next = tempNode->next;
			}
			free(tempNode);
		}
		else
		{
			preNode = tempNode;
		}
		
	}
	printf("\n\n");
	printList(wordlist);
	
	removeList(wordlist, stopwordsFile);

	printf("\n\n");
	printList(wordlist);

	destroyList(wordlist);
	
	return 0;
}
